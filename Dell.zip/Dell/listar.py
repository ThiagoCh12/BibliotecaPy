import cadastro

def listar_cliente():
    
    

    return 0
def listar_livro():


    return 0
def listar_emprestimo():


    return 0
def listar_atrasos():


    return 0