import os
import csv
import pesquisar as p

def emprestar_livro():

    Emprestimo = [] 
    
    nome_cliente = input("Digite o nome do usuario: ")
    retorno_usuario = p.pesquisar_cliente(nome_cliente)
    
    if retorno_usuario[0] == True:
        codigo_livro = input("Digite o codigo do livro:")
        retorno_livro = p.pesquisar_livro(codigo_livro)

        if retorno_livro[0] == True:
            print('nome do livro:', retorno_livro[1])
            r = input("Deseja emprestar o livro {} para {}? s/n".format(retorno_livro[1], nome_cliente))
            if r == s:
                Emprestimo = [retorno_livro, retorno_usuario]

        else:
            print("Livro nao encontrado")

    else:
        print("Usuario nao encontrado")

    return 0